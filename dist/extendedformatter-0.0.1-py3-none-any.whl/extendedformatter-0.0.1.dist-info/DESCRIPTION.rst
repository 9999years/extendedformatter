https://github.com/9999years/extendedformatter/blob/master/readme.md


